
const router = require("express").Router();
const got = require('got');
const config = require('../config/jwtHelper');
const Hospital = require('../models/hospital.server.model');
const AssignHospital = require('../models/assignHospital.server.model');
const AppStatus = require('../models/appStatus.server.model');

router.get("/getAllHospitals",config.verifyToken, async (req,res) => {
    console.log("I am in Get All Hospital deatils");
    
    Hospital.find({rm_assigned : null }).exec().then(data=>{
            res.status(201).json({
                message: "OK",
                results : data
            });
    })
        .catch(err=>{
            res.json(err);
        }); 
});

router.get('/getAssignedHospital',config.verifyToken,(req,res)=> {
    Hospital.find({rm_assigned:{$ne:null}}).populate(['rm_assigned']).exec().then(data=>{
        res.status(201).json({
            message: "OK",
            results : data
        });
})
    .catch(err=>{
        res.json(err);
    });
});

router.get('/getInactiveHospital',config.verifyToken, async (req,res)=> {
    Hospital.find({is_disabled : true }).exec().then(data=>{
        res.status(201).json({
            message: "OK",
            results : data
        });
})
    .catch(err=>{
        res.json(err);
    });
});


router.post("/assignHospitalToUser",config.verifyToken, async (req,res) => {
    console.log(req.body.userId)
    const updateHospDetails = {
        rm_assigned : req.body.userId
    }
    AssignHospital.findOne({ userId : req.body.userId }).exec().then(data=>{
        var hospitalId = req.body.assignedHospital;
        console.log(hospitalId);
        if(data){
            const updateDocument = {
                $push: { "hospitalId": req.body.assignedHospital }
                //updated_on : Date.now
              };
         AssignHospital.findByIdAndUpdate({_id : data._id}, updateDocument).exec().then(dataNew=>{
            hospitalId.forEach(function(assignedHospital){
                Hospital.findByIdAndUpdate({_id : assignedHospital}, updateHospDetails).exec(function(error, hosp){
                });
            });
            res.status(201).json({
                message: "OK",
                results : data
            });
        }).catch(err=>{
            res.json(err);
        }); 
    }
        else{
            const assign = new AssignHospital({
                userId : req.body.userId,
                designation : req.body.designation,
                hospitalId : req.body.assignedHospital,
            });
            assign.save().then(data=>{
                hospitalId.forEach(function(assignedHospital){
                    Hospital.findByIdAndUpdate({_id : assignedHospital}, updateHospDetails).exec(function(error, hosp){
                    });
                });
                res.status(201).json({
                    message: "OK",
                    results : data
                });
            }).catch(err=>{
                res.json(err);
            }); 
        }
    });
});

router.get('/alluserWithHospital',config.verifyToken, async (req,res) => {
    AssignHospital.find({}).populate(['hospitalId','userId','designation']).exec().then(data=>{
        res.status(201).json({
            message: "OK",
            results : data
        });
})
    .catch(err=>{
        res.json(err);
    }); 
});




module.exports = router;
