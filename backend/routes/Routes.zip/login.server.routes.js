'use strict';
const router = require('express').Router();
var passport = require('passport');
const Designation = require('../models/addDesignation.server.model');

router.post('/login',(req,res, next) => {
  console.log(req.body)
  passport.authenticate('local',(err, user, info) => {
    console.log(user)
      if(err){
        return res.status(400).json(err);
      }
      else if(user){
        var token = user.generateJwt();
        console.log(user.designation)
        Designation.findOne({ _id : user.designation }).exec().then(data=>{
          console.log(data)
            return res.send({
              success: true,
              name:user.name,
              email:user.email,
              token: token,
              desig : data.designation
          });
        });
      }
      else{
        return res.status(404).json(info);
      }
    })(req, res);
});


module.exports = router;